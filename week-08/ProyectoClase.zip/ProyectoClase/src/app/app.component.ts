import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Persona } from './persona/persona.model';
import { CommonModule } from '@angular/common';
import { PersonaComponent } from './persona/persona.component';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  imports: [PersonaComponent] 
})
export class AppComponent {
  cliente: Persona = {
    nombre: 'Juan',
    apellido: 'Pérez',
    documento: '12345678',
    fechaNacimiento: '1985-06-15',
    direccion: 'Calle Falsa 123',
    telefono: '555-1234',
    correo: 'juan.perez@example.com',
    tipo: 'cliente'
  };

  proveedor: Persona = {
    nombre: 'María',
    apellido: 'Gómez',
    documento: '87654321',
    fechaNacimiento: '1978-09-23',
    direccion: 'Av. Siempre Viva 742',
    telefono: '555-5678',
    correo: 'maria.gomez@example.com',
    tipo: 'proveedor'
  };
}
