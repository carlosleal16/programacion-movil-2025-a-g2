export interface Persona {
    nombre: string;
    apellido: string;
    documento: string;
    fechaNacimiento: string;
    direccion: string;
    telefono: string;
    correo: string;
    tipo: 'cliente' | 'proveedor';
  }
  